echo " "
echo "Licencia para lang-esp, autor: https://github.com/VWolf13/"
echo "Copyright (c) 2020, Equipo comunidad VWolf"
echo "Todos los derechos reservados"
echo "Todos tienen permitido copiar y distribuir copias literales de este documento de licencia, pero no está permitido cambiarlo / modificarlo"
echo " "
echo "Vistianos ^^: https://vwolf.site

